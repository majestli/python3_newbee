class UrlManager(object):
    def __init__(self):
        pass

    def get_main_seed_url(self):
        return 'https://www.meitulu.com/'

